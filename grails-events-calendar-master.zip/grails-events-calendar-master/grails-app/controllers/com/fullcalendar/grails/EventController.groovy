package com.fullcalendar.grails

class EventController {

    def scaffold = true

}
