Demo App for Grails with DHTMLX JavaPlanner 

Read tutorial http://javaplanner.com/docs/using_javaplanner_with_the_grails_framework.html

To purchase Commercial/Enterprise Licence visit http://javaplanner.com/license.html

(c) DHTMLX Ltd. 