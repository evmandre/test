package ourproject

class EventCategoryController {

    def scaffold = EventCategory
}
