package ourproject

class EventController {

    def scaffold = Event
}
