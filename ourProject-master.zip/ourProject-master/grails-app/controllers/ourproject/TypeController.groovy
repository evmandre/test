package ourproject

class TypeController {

   def scaffold = Type
}
