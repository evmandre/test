package ourproject

class EventCategory {
	
	String categoryName
	static hasMany = [type :Type,events :Event]
//	static belongsTo = [type :EventType]
	
//    static mapping = {
//		
//		tablePerHierarchy false
////		id column : 'class'
//		
//	}
	
	static constraints = {
	
//		id column : 'category'
}
//		tablePerHierarchy false
		
}
