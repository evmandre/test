package ourproject


class Event {
	
	String title
//	String eventCategory
//	EventCategory eventCategory
	static belongsTo = [category :EventCategory,type:Type]
 //	static embedded = ['eventType']
//	def nursesWithoutPatients = Types.withCriteria { isEmpty("patients") }
//	 EventType.executeQuery("select distinct e. from EventCategory e",
//		"where e. = :eventCategory")
	
	Date dateOFevent
	String description
	BigDecimal fee
	String contactInfo
//	Image imageOFevent
//	Address locationOFevent	
	
//	String type
//	
//	static mapping = {
//		type formula: '(select t.TYPEOF_CATEGORY from TYPES t where (t.TYPEOF_CATEGORY = CATEGORY_ID))'
//		}
	
	String toString(){
		
		"$title, $dateOFevent, $description, $contactInfo, $fee"
		
		}
	
    static constraints = {
    }
}
