package ourproject

class Type {

	String typeofCategory
	static belongsTo = [category :EventCategory]
	
    static constraints = {
    }
}
