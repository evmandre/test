(function()
{
  var mc = document.createElement('script');
  mc.type = 'text/javascript';
  mc.async = true;
  mc.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://cackle.me/widget.js';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(mc, s.nextSibling);
})();