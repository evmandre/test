class UrlMappings {
	static mappings = {
		"/initializing"(controller: "Loading", action: "initializing")
		"/events"(controller: "Loading", action: "events")
	}
}