package demoapp



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Demoapp_grails)
class Demoapp_grailsTests {

    void testSomething() {
       fail "Implement me"
    }
}
